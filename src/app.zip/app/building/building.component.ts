import { Component, Input, OnInit } from '@angular/core';
import Building from '../building';
import { Subscription } from 'rxjs';
import { ClockService } from '../clock.service';

@Component({
  selector: 'app-building',
  templateUrl: './building.component.html',
  styleUrls: ['./building.component.css']
})
export class BuildingComponent implements OnInit{

  constructor(private clockService:ClockService){};

  clockSubscription!:Subscription;

  ngOnInit(): void {
      this.clockSubscription = this.clockService.clock.subscribe
      (
        n=>this.building.production+=this.building.productionrate
      );
  }

  @Input() building!:Building;

  getClass():string{
    return "w3-col m1 l1 building " + this.building.type;    
  }

}
