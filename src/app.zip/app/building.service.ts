import { Injectable } from '@angular/core';
import Building from './building';

@Injectable({
  providedIn: 'root'
})
export class BuildingService {

  add(newBuilding: Building) {
    let copy:Building = {...newBuilding};
    this.buildings.push(copy);
  }

  buildings:Building[] =  
  [
      {
          name:'Bananas Libres',
          type:'Farm',
          product:'Banana',
          production:0,
          productionrate:5
      },
      {
        name:'Bananas Solidales',
        type:'Farm',
        product:'Banana',
        production:0,
        productionrate:2
    }
  ]

  getBuildings(): Building[]  {
    return this.buildings;
  }

  

  constructor() { }
}
