import { Component } from '@angular/core';
import Building from './building';
import { BuildingService } from './building.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ngTropico';

  buildings:Building[];

  constructor(private buildingService:BuildingService){
    this.buildings = buildingService.getBuildings();
  }

  addBuilding(b:Building):void {
    let c:Building = {...b};
    this.buildings.push(c);
  }
  

}
