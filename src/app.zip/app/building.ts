export default interface Building {

    type:"House"|"Service"|"Industry"|"Farm";
    name:string;
    
    product:string;
    productionrate:number;
    production:number;
}