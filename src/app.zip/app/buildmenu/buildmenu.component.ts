import { Component } from '@angular/core';
import Building from '../building';
import { BuildingService } from '../building.service';

@Component({
  selector: 'app-buildmenu',
  templateUrl: './buildmenu.component.html',
  styleUrls: ['./buildmenu.component.css']
})
export class BuildmenuComponent {

  constructor(private buildingService:BuildingService){}
  selected:string = '';
  newBuilding:Building= {name:'', type:'Farm', product:'Wheat', production:0, productionrate:0};

  add():void{
      this.buildingService.add(this.newBuilding);
  }


}
